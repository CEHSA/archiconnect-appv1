<?php if (isset($component)) { $__componentOriginalaad3e3cd25b22ee82ac09a10304e1c0e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaad3e3cd25b22ee82ac09a10304e1c0e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.freelancer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.freelancer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Job Details')); ?>

     <?php $__env->endSlot(); ?>

    
    
    <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border border-green-300">
        <div class="p-6 text-gray-900">
            <h3 class="text-2xl font-semibold mb-4 text-gray-900"><?php echo e($job->title); ?></h3>

            <dl class="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4 mb-6">
                <div>
                    <dt class="text-sm font-medium text-gray-500"><?php echo e(__('Client')); ?></dt>
                    <dd class="mt-1 text-sm text-gray-900"><?php echo e($job->user ? $job->user->name : __('Not Specified')); ?></dd>
                </div>
                <div>
                    <dt class="text-sm font-medium text-gray-500"><?php echo e(__('Status')); ?></dt>
                    <dd class="mt-1 text-sm text-gray-900"><?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $job->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></dd>
                </div>
                <div>
                    <dt class="text-sm font-medium text-gray-500"><?php echo e(__('Budget')); ?></dt>
                    <dd class="mt-1 text-sm text-gray-900"><?php echo e($job->budget ? format_currency($job->budget) : __('Not Specified')); ?></dd>
                </div>
                <div>
                    <dt class="text-sm font-medium text-gray-500"><?php echo e(__('Hourly Rate')); ?></dt>
                    <dd class="mt-1 text-sm text-gray-900"><?php echo e($job->hourly_rate ? format_currency($job->hourly_rate) . ' / hour' : __('Not Specified')); ?></dd>
                </div>
                <div>
                    <dt class="text-sm font-medium text-gray-500"><?php echo e(__('Not to Exceed Budget')); ?></dt>
                    <dd class="mt-1 text-sm text-gray-900"><?php echo e($job->not_to_exceed_budget ? format_currency($job->not_to_exceed_budget) : __('Not Specified')); ?></dd>
                </div>
                <div>
                    <dt class="text-sm font-medium text-gray-500"><?php echo e(__('Posted Date')); ?></dt>
                    <dd class="mt-1 text-sm text-gray-900"><?php echo e($job->created_at->format('M d, Y')); ?></dd>
                </div>
            </dl>

            <div class="mb-6">
                <p class="text-sm font-medium text-gray-500"><?php echo e(__('Description')); ?></p>
                <div class="prose max-w-none mt-1 text-sm text-gray-900">
                    <?php echo $job->description; ?>

                </div>
            </div>

            <?php if($job->skills_required): ?>
            <div class="mb-6">
                <p class="text-sm font-medium text-gray-500"><?php echo e(__('Skills Required')); ?></p>
                <p class="mt-1 text-sm text-gray-900"><?php echo e($job->skills_required); ?></p>
            </div>
            <?php endif; ?>

            
            <?php if($job->status === 'open' || $job->status === 'pending'): ?> 
                <div class="mt-6">
                     
                    <?php
                        $hasProposed = Auth::user()->proposals()->where('job_id', $job->id)->exists();
                    ?>

                    <?php if($hasProposed): ?>
                        <p class="text-green-600"><?php echo e(__('You have already submitted a proposal for this job.')); ?></p>
                        <a href="<?php echo e(route('freelancer.proposals.show', ['proposal' => Auth::user()->proposals()->where('job_id', $job->id)->first()->id])); ?>" class="inline-flex items-center px-4 py-2 bg-gray-200 border border-transparent rounded-md font-semibold text-xs text-gray-700 uppercase tracking-widest hover:bg-gray-300 active:bg-gray-400 focus:outline-none focus:border-gray-300 focus:ring ring-gray-300 disabled:opacity-25 transition ease-in-out duration-150 mt-2">
                            <?php echo e(__('View Your Proposal')); ?>

                        </a>
                    <?php else: ?>
                        
                        <?php if(Route::has('freelancer.proposals.store')): ?> 
                            <a href="" class="inline-flex items-center px-4 py-2 bg-cyan-700 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-cyan-600 focus:bg-cyan-600 active:bg-cyan-800 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2 transition ease-in-out duration-150">
                                <?php echo e(__('Submit a Proposal')); ?> (Coming Soon)
                            </a>
                        <?php else: ?>
                            <p class="text-blue-600"><?php echo e(__('Proposal submission will be available soon.')); ?></p>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="mt-8">
                <a href="<?php echo e(route('freelancer.jobs.browse')); ?>" class="text-sm text-gray-600 hover:text-gray-900 underline">
                    &larr; <?php echo e(__('Back to Job Listings')); ?>

                </a>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaad3e3cd25b22ee82ac09a10304e1c0e)): ?>
<?php $attributes = $__attributesOriginalaad3e3cd25b22ee82ac09a10304e1c0e; ?>
<?php unset($__attributesOriginalaad3e3cd25b22ee82ac09a10304e1c0e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaad3e3cd25b22ee82ac09a10304e1c0e)): ?>
<?php $component = $__componentOriginalaad3e3cd25b22ee82ac09a10304e1c0e; ?>
<?php unset($__componentOriginalaad3e3cd25b22ee82ac09a10304e1c0e); ?>
<?php endif; ?>
<?php /**PATH D:\Coding\git\architex-lava\archiconnect-app\resources\views/freelancer/jobs/show.blade.php ENDPATH**/ ?>