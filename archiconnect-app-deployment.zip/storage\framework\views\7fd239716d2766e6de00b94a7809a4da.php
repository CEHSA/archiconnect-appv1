<?php if (isset($component)) { $__componentOriginalaad3e3cd25b22ee82ac09a10304e1c0e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaad3e3cd25b22ee82ac09a10304e1c0e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.freelancer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.freelancer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Freelancer Dashboard')); ?>

     <?php $__env->endSlot(); ?>

    <!-- Freelancer Summary Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <div class="bg-white p-6 rounded-xl shadow-lg flex items-center space-x-4 border border-green-300">
            <div class="p-3 bg-purple-500 bg-opacity-20 rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16l3.5-2 3.5 2 3.5-2 3.5 2zM10 13h4m-4-4h4" /></svg>
            </div>
            <div>
                <p class="text-gray-500 text-sm">Active Assignments</p>
                <p class="text-2xl font-semibold text-gray-800"><?php echo e($activeAssignmentsCount ?? 0); ?></p>
            </div>
        </div>
        <div class="bg-white p-6 rounded-xl shadow-lg flex items-center space-x-4 border border-green-300">
            <div class="p-3 bg-red-500 bg-opacity-20 rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" /></svg> 
            </div>
            <div>
                <p class="text-gray-500 text-sm">Pending Proposals</p>
                <p class="text-2xl font-semibold text-gray-800"><?php echo e($pendingProposalsCount ?? 0); ?></p>
            </div>
        </div>
         <div class="bg-white p-6 rounded-xl shadow-lg flex items-center space-x-4 border border-green-300">
            <div class="p-3 bg-teal-500 bg-opacity-20 rounded-full">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-teal-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
            </div>
            <div>
                <p class="text-gray-500 text-sm">Tasks Due Soon</p> 
                <p class="text-2xl font-semibold text-gray-800"><?php echo e($tasksDueSoonCount ?? 0); ?></p>
            </div>
        </div>
    </div>

    <div class="space-y-8">
        <!-- New Job Opportunities -->
        <div class="bg-white p-6 rounded-xl shadow-lg border border-green-300">
            <h3 class="text-xl font-semibold text-gray-800 mb-4">New Job Opportunities</h3>
            <div class="space-y-4">
                 <?php $__empty_1 = true; $__currentLoopData = $newJobOpportunities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
                        <div class="flex flex-col sm:flex-row justify-between sm:items-center">
                            <div>
                                <p class="font-medium text-gray-700"><?php echo e($job->title); ?></p>
                                <p class="text-xs text-gray-500">Client: <?php echo e($job->client->name ?? 'N/A'); ?></p>
                            </div>
                            <div class="mt-2 sm:mt-0">
                                <a href="<?php echo e(route('freelancer.jobs.show', $job->id)); ?>" class="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-cyan-600 hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500 transition ease-in-out duration-150">
                                    View Job
                                </a>
                            </div>
                        </div>
                        <p class="text-sm text-gray-600 mt-1">Status: <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $job->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($job->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500">No new job opportunities available at the moment.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- My Active Jobs -->
        <div class="bg-white p-6 rounded-xl shadow-lg border border-green-300">
            <h3 class="text-xl font-semibold text-gray-800 mb-4">My Active Jobs</h3>
            <div class="space-y-4">
                 <?php $__empty_1 = true; $__currentLoopData = $activeJobAssignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
                        <div class="flex flex-col sm:flex-row justify-between sm:items-center">
                            <div>
                                <p class="font-medium text-gray-700"><?php echo e($assignment->job->title); ?></p>
                                <p class="text-xs text-gray-500">Client: <?php echo e($assignment->job->client->name ?? 'N/A'); ?></p>
                            </div>
                            <div class="mt-2 sm:mt-0">
                                <a href="<?php echo e(route('freelancer.assignments.show', $assignment->id)); ?>" class="inline-flex items-center px-3 py-1.5 border border-gray-300 text-xs font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500 transition ease-in-out duration-150">
                                    View Details / Comments
                                </a>
                                
                            </div>
                        </div>
                        <p class="text-sm text-gray-600 mt-1">Status: <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $assignment->derived_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($assignment->derived_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></p>
                        
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500">You have no active jobs assigned.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- My Completed Jobs -->
        <div class="bg-white p-6 rounded-xl shadow-lg border border-green-300">
            <h3 class="text-xl font-semibold text-gray-800 mb-4">My Completed Jobs</h3>
            <div class="space-y-4">
                 <?php $__empty_1 = true; $__currentLoopData = $completedJobAssignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
                        <div class="flex flex-col sm:flex-row justify-between sm:items-center">
                            <div>
                                <p class="font-medium text-gray-700"><?php echo e($assignment->job->title); ?></p>
                                <p class="text-xs text-gray-500">Client: <?php echo e($assignment->job->client->name ?? 'N/A'); ?></p>
                            </div>
                             <div class="mt-2 sm:mt-0">
                                <a href="<?php echo e(route('freelancer.assignments.show', $assignment->id)); ?>" class="inline-flex items-center px-3 py-1.5 border border-gray-300 text-xs font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500 transition ease-in-out duration-150">
                                    View Details
                                </a>
                            </div>
                        </div>
                        <p class="text-sm text-gray-600 mt-1">Status: <?php if (isset($component)) { $__componentOriginal8c81617a70e11bcf247c4db924ab1b62 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.status-badge','data' => ['status' => $assignment->derived_status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($assignment->derived_status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $attributes = $__attributesOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__attributesOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62)): ?>
<?php $component = $__componentOriginal8c81617a70e11bcf247c4db924ab1b62; ?>
<?php unset($__componentOriginal8c81617a70e11bcf247c4db924ab1b62); ?>
<?php endif; ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500">You have no completed jobs.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaad3e3cd25b22ee82ac09a10304e1c0e)): ?>
<?php $attributes = $__attributesOriginalaad3e3cd25b22ee82ac09a10304e1c0e; ?>
<?php unset($__attributesOriginalaad3e3cd25b22ee82ac09a10304e1c0e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaad3e3cd25b22ee82ac09a10304e1c0e)): ?>
<?php $component = $__componentOriginalaad3e3cd25b22ee82ac09a10304e1c0e; ?>
<?php unset($__componentOriginalaad3e3cd25b22ee82ac09a10304e1c0e); ?>
<?php endif; ?>
<?php /**PATH D:\Coding\git\architex-lava\archiconnect-app\resources\views/freelancer/dashboard.blade.php ENDPATH**/ ?>