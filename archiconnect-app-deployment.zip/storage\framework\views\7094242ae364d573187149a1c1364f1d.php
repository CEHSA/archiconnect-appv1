

<?php if (isset($component)) { $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.admin','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.admin'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <?php echo e(__('Admin Dashboard')); ?>

     <?php $__env->endSlot(); ?>

    <!-- Summary Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <!-- Total Projects Card -->
        <div class="bg-white p-6 rounded-xl shadow-lg flex items-center space-x-4">
            <div class="p-3 bg-blue-500 bg-opacity-20 rounded-full">
                
                <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
            </div>
            <div>
                <p class="text-gray-500 text-sm">Total Projects</p>
                <p class="text-2xl font-semibold text-gray-800"><?php echo e($stats['totalProjects']); ?></p>
            </div>
        </div>
        <!-- Active Projects Card -->
        <div class="bg-white p-6 rounded-xl shadow-lg flex items-center space-x-4">
            <div class="p-3 bg-yellow-500 bg-opacity-20 rounded-full">
                
                <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-yellow-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            </div>
            <div>
                <p class="text-gray-500 text-sm">Active Projects</p>
                <p class="text-2xl font-semibold text-gray-800"><?php echo e($stats['activeProjects']); ?></p>
            </div>
        </div>
        <!-- Completed Projects Card -->
        <div class="bg-white p-6 rounded-xl shadow-lg flex items-center space-x-4">
             <div class="p-3 bg-green-500 bg-opacity-20 rounded-full">
                
                <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            </div>
            <div>
                <p class="text-gray-500 text-sm">Completed Projects</p>
                <p class="text-2xl font-semibold text-gray-800"><?php echo e($stats['completedProjects']); ?></p>
            </div>
        </div>
        <!-- Total Hours Logged Card -->
         <div class="bg-white p-6 rounded-xl shadow-lg flex items-center space-x-4">
            <div class="p-3 bg-indigo-500 bg-opacity-20 rounded-full">
                
                <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" /></svg>
            </div>
            <div>
                <p class="text-gray-500 text-sm">Total Hours Logged</p>
                <p class="text-2xl font-semibold text-gray-800"><?php echo e(number_format($stats['totalHoursLogged'], 1)); ?></p>
            </div>
        </div>
    </div>

    <!-- Recent Jobs and Activity -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Recent Jobs -->
        <div class="bg-white p-6 rounded-xl shadow-lg">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Recent Jobs</h3>
            <div class="space-y-3 overflow-y-auto" style="max-height: 400px;"> 
                <?php $__empty_1 = true; $__currentLoopData = $recentJobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="p-3 border border-gray-200 rounded-lg hover:shadow-md transition-shadow bg-gray-50">
                        <div class="flex justify-between items-start">
                            <div>
                                <a href="<?php echo e(route('admin.jobs.show', $job)); ?>" class="font-medium text-cyan-700 hover:text-cyan-600 hover:underline"><?php echo e($job->title); ?></a>
                                <p class="text-sm text-gray-600 capitalize">Status: <span class="font-medium"><?php echo e(str_replace('_', ' ', $job->status)); ?></span></p>
                            </div>
                            <p class="text-xs text-gray-500 whitespace-nowrap ml-2"><?php echo e($job->created_at->format('m/d/Y')); ?></p>
                        </div>
                        
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500">No recent jobs found.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="bg-white p-6 rounded-xl shadow-lg">
            <h3 class="text-lg font-semibold text-gray-800 mb-4">Recent Activity</h3>
             <div class="space-y-4">
                <?php $__empty_1 = true; $__currentLoopData = $recentActivity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity_log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="p-4 border rounded-lg hover:shadow-md transition-shadow">
                        <p class="text-sm text-gray-700"><?php echo e($activity_log->description); ?></p>
                        <div class="flex justify-between items-center mt-1">
                            <p class="text-xs text-gray-500">
                                By: <?php echo e($activity_log->admin ? $activity_log->admin->name : 'System'); ?>

                            </p>
                            <p class="text-xs text-gray-500">
                                <?php echo e($activity_log->created_at->format('m/d/Y H:i A')); ?>

                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-500">No recent admin activity.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $attributes = $__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__attributesOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3)): ?>
<?php $component = $__componentOriginalc8c9fd5d7827a77a31381de67195f0c3; ?>
<?php unset($__componentOriginalc8c9fd5d7827a77a31381de67195f0c3); ?>
<?php endif; ?>
<?php /**PATH D:\Coding\git\architex-lava\archiconnect-app\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>