<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e(config('app.name', 'ArchiTimeX Keeper')); ?> Admin</title>
        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <style>
            .subtle-grid {
                background-image: linear-gradient(to right, rgba(200, 200, 200, 0.1) 1px, transparent 1px),
                                linear-gradient(to bottom, rgba(200, 200, 200, 0.1) 1px, transparent 1px);
                background-size: 20px 20px; /* Adjust grid size */
            }
        </style>
        <?php echo $__env->yieldPushContent('styles'); ?> 
    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen flex bg-architimex-lightbg">
            <!-- Sidebar -->
            <aside class="w-64 bg-architimex-sidebar text-white flex-shrink-0">
                <div class="p-4 flex items-center space-x-2 border-b border-gray-700">
                    <img src="<?php echo e(asset('images/bird_logo.png')); ?>" alt="Logo" class="h-10 w-auto invert brightness-0"> 
                    <h1 class="text-xl font-semibold"><?php echo e(config('app.name', 'ArchiTimeX Keeper')); ?></h1>
                </div>
                <nav class="mt-4 px-2">
                    
                    <?php if (isset($component)) { $__componentOriginal587edaf313e0ec074acea90d82299dd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal587edaf313e0ec074acea90d82299dd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-nav-link','data' => ['href' => route('admin.dashboard'),'active' => request()->routeIs('admin.dashboard')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.dashboard')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.dashboard'))]); ?>
                        <?php echo e(__('Dashboard')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $attributes = $__attributesOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__attributesOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $component = $__componentOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__componentOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal587edaf313e0ec074acea90d82299dd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal587edaf313e0ec074acea90d82299dd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-nav-link','data' => ['href' => route('admin.jobs.index'),'active' => request()->routeIs('admin.jobs.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.jobs.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.jobs.*'))]); ?>
                        <?php echo e(__('Jobs')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $attributes = $__attributesOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__attributesOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $component = $__componentOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__componentOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal587edaf313e0ec074acea90d82299dd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal587edaf313e0ec074acea90d82299dd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-nav-link','data' => ['href' => route('admin.messages.index'),'active' => request()->routeIs('admin.messages.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.messages.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.messages.*'))]); ?>
                        <div class="flex items-center justify-between">
                            <span><?php echo e(__('Messages')); ?></span>
                            <?php if(isset($unreadMessagesCount) && $unreadMessagesCount > 0): ?>
                                <span class="ml-2 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-red-100 bg-red-600 rounded-full">
                                    <?php echo e($unreadMessagesCount); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $attributes = $__attributesOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__attributesOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $component = $__componentOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__componentOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>
                    
                    <?php if (isset($component)) { $__componentOriginal587edaf313e0ec074acea90d82299dd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal587edaf313e0ec074acea90d82299dd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-nav-link','data' => ['href' => route('admin.users.index'),'active' => request()->routeIs('admin.users.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.users.index')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.users.*'))]); ?>
                        <?php echo e(__('Users')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $attributes = $__attributesOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__attributesOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $component = $__componentOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__componentOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>
                    
                    <?php if (isset($component)) { $__componentOriginal587edaf313e0ec074acea90d82299dd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal587edaf313e0ec074acea90d82299dd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-nav-link','data' => ['href' => route('admin.reports.job-progress'),'active' => request()->routeIs('admin.reports.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.reports.job-progress')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.reports.*'))]); ?>
                        <?php echo e(__('Reports')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $attributes = $__attributesOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__attributesOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $component = $__componentOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__componentOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>
                    
                    
                    <?php if (isset($component)) { $__componentOriginal587edaf313e0ec074acea90d82299dd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal587edaf313e0ec074acea90d82299dd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-nav-link','data' => ['href' => route('admin.reports.client-project-status'),'active' => request()->routeIs('admin.reports.client-project-status'),'class' => 'ml-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.reports.client-project-status')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.reports.client-project-status')),'class' => 'ml-4']); ?>
                        <?php echo e(__('Client Project Status')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $attributes = $__attributesOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__attributesOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $component = $__componentOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__componentOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal587edaf313e0ec074acea90d82299dd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal587edaf313e0ec074acea90d82299dd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-nav-link','data' => ['href' => route('admin.reports.financials'),'active' => request()->routeIs('admin.reports.financials'),'class' => 'ml-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.reports.financials')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.reports.financials')),'class' => 'ml-4']); ?>
                        <?php echo e(__('Financials')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $attributes = $__attributesOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__attributesOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $component = $__componentOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__componentOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>

                     <?php if (isset($component)) { $__componentOriginal587edaf313e0ec074acea90d82299dd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal587edaf313e0ec074acea90d82299dd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-nav-link','data' => ['href' => route('admin.dashboard'),'active' => request()->routeIs('admin.settings.*')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.dashboard')),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('admin.settings.*'))]); ?> 
                        <?php echo e(__('Settings')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $attributes = $__attributesOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__attributesOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal587edaf313e0ec074acea90d82299dd9)): ?>
<?php $component = $__componentOriginal587edaf313e0ec074acea90d82299dd9; ?>
<?php unset($__componentOriginal587edaf313e0ec074acea90d82299dd9); ?>
<?php endif; ?>
                </nav>
                <div class="p-4 mt-auto border-t border-gray-700">
                    <div class="flex items-center space-x-3">
                        
                        <div class="w-10 h-10 rounded-full bg-gray-500 flex items-center justify-center text-white font-semibold">
                            <?php echo e(strtoupper(substr(Auth::guard('admin')->user()->name, 0, 1))); ?>

                        </div>
                        <div>
                            <p class="text-sm font-medium"><?php echo e(Auth::guard('admin')->user()->name); ?></p>
                            <p class="text-xs text-gray-400"><?php echo e(ucfirst(Auth::guard('admin')->user()->role)); ?></p>
                        </div>
                    </div>
                </div>
            </aside>

            <!-- Main content -->
            <div class="flex-1 flex flex-col overflow-hidden">
                <!-- Top header bar -->
                <header class="bg-white shadow-sm">
                    <div class="max-w-full mx-auto py-4 px-4 sm:px-6 lg:px-8 flex justify-between items-center">
                        <!-- Page Specific Header -->
                        <?php if(isset($header)): ?>
                            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                                <?php echo e($header); ?>

                            </h2>
                        <?php endif; ?>

                        <!-- Right side of header: Notifications, User dropdown -->
                        <div class="flex items-center space-x-4">
                           <!-- Notifications Bell Icon -->
                           <a href="<?php echo e(route('notifications.index')); ?>" class="relative text-gray-500 hover:text-gray-700">
                                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg>
                                <?php if(Auth::guard('admin')->user()->unreadNotifications->count() > 0): ?>
                                    <span class="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-red-100 transform translate-x-1/2 -translate-y-1/2 bg-red-600 rounded-full">
                                        <?php echo e(Auth::guard('admin')->user()->unreadNotifications->count()); ?>

                                    </span>
                                <?php endif; ?>
                           </a>
                            <!-- Settings Dropdown -->
                            <div class="hidden sm:flex sm:items-center sm:ms-6">
                                <?php if (isset($component)) { $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown','data' => ['align' => 'right','width' => '48']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['align' => 'right','width' => '48']); ?>
                                     <?php $__env->slot('trigger', null, []); ?> 
                                        <button class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-gray-500 bg-white hover:text-gray-700 focus:outline-none transition ease-in-out duration-150">
                                            <div><?php echo e(Auth::guard('admin')->user()->name); ?></div>
                                            <div class="ms-1">
                                                <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                                                    <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
                                                </svg>
                                            </div>
                                        </button>
                                     <?php $__env->endSlot(); ?>
                                     <?php $__env->slot('content', null, []); ?> 
                                        <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('profile.edit')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('profile.edit'))]); ?> 
                                            <?php echo e(__('Profile')); ?>

                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
                                        <!-- Authentication -->
                                        <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('admin.logout'),'onclick' => 'event.preventDefault();
                                                                this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('admin.logout')),'onclick' => 'event.preventDefault();
                                                                this.closest(\'form\').submit();']); ?>
                                                <?php echo e(__('Log Out')); ?>

                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
                                        </form>
                                     <?php $__env->endSlot(); ?>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $attributes = $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $component = $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
                            </div>
                        </div>
                    </div>
                </header>

                <!-- Main page content -->
                <main class="flex-1 overflow-x-hidden overflow-y-auto subtle-grid">
                    <div class="container mx-auto px-6 py-8">
                        <?php echo e($slot); ?>

                    </div>
                </main>
            </div>
        </div>
        <?php echo $__env->yieldPushContent('scripts'); ?> 
    </body>
</html>
<?php /**PATH D:\Coding\git\architex-lava\archiconnect-app\resources\views/components/admin-layout.blade.php ENDPATH**/ ?>