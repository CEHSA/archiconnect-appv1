<?php extract((new \Illuminate\Support\Collection($attributes->getAttributes()))->mapWithKeys(function ($value, $key) { return [Illuminate\Support\Str::camel(str_replace([':', '.'], ' ', $key)) => $value]; })->all(), EXTR_SKIP); ?>

<?php if (isset($component)) { $__componentOriginalaad3e3cd25b22ee82ac09a10304e1c0e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaad3e3cd25b22ee82ac09a10304e1c0e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.freelancer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.freelancer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
 <?php $__env->slot('header', null, []); ?> <?php echo e($header); ?> <?php $__env->endSlot(); ?>
<?php echo e($slot ?? ""); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaad3e3cd25b22ee82ac09a10304e1c0e)): ?>
<?php $attributes = $__attributesOriginalaad3e3cd25b22ee82ac09a10304e1c0e; ?>
<?php unset($__attributesOriginalaad3e3cd25b22ee82ac09a10304e1c0e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaad3e3cd25b22ee82ac09a10304e1c0e)): ?>
<?php $component = $__componentOriginalaad3e3cd25b22ee82ac09a10304e1c0e; ?>
<?php unset($__componentOriginalaad3e3cd25b22ee82ac09a10304e1c0e); ?>
<?php endif; ?><?php /**PATH D:\Coding\git\architex-lava\archiconnect-app\storage\framework\views/e8cbe8a1abacee9a209abe1481520537.blade.php ENDPATH**/ ?>