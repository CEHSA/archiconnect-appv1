<?php if (isset($component)) { $__componentOriginal3437ffb4a666c895e3d1a523818d1122 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3437ffb4a666c895e3d1a523818d1122 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.freelancer-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('freelancer-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="text-gray-700 text-3xl font-medium">
                <?php echo e(__('Messages')); ?>

            </h2>
            <a href="<?php echo e(route('freelancer.messages.createAdmin')); ?>" class="inline-flex items-center px-4 py-2 bg-cyan-700 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-cyan-600 focus:bg-cyan-600 active:bg-cyan-800 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2 transition ease-in-out duration-150">
                <?php echo e(__('New Message to Admin')); ?>

            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg border border-green-300">
                <div class="p-6 text-gray-900">
                    <?php if($conversations->isEmpty()): ?>
                        <div class="text-center py-8">
                            <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                            </svg>
                            <h3 class="mt-2 text-sm font-medium text-gray-900"><?php echo e(__('No messages')); ?></h3>
                            <p class="mt-1 text-sm text-gray-500">
                                <?php echo e(__("You don't have any message conversations yet.")); ?>

                            </p>
                        </div>
                    <?php else: ?>
                        <h4 class="text-xl font-medium text-gray-700 mb-4"><?php echo e(__('All Conversations')); ?></h4>
                        <div class="flex flex-col">
                            <div class="-my-2 py-2 overflow-x-auto sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8">
                                <div class="align-middle inline-block min-w-full shadow overflow-hidden sm:rounded-lg border-b border-gray-200">
                                    <table class="min-w-full">
                                        <thead>
                                            <tr>
                                                <th class="px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
                                                    
                                                </th>
                                                <th class="px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
                                                    <?php echo e(__('Participant')); ?>

                                                </th>
                                                <th class="px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
                                                    <?php echo e(__('Related Job')); ?>

                                                </th>
                                                <th class="px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
                                                    <?php echo e(__('Last Message')); ?>

                                                </th>
                                                <th class="px-6 py-3 border-b border-gray-200 bg-gray-50 text-left text-xs leading-4 font-medium text-gray-500 uppercase tracking-wider">
                                                    <?php echo e(__('Last Activity')); ?>

                                                </th>
                                                <th class="px-6 py-3 border-b border-gray-200 bg-gray-50"></th>
                                            </tr>
                                        </thead>
                                        <tbody class="bg-white">
                                            <?php $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $currentUser = auth()->user();
                                                    $otherParticipant = null;
                                                    if ($conversation->participant1_id === $currentUser->id) {
                                                        $otherParticipant = $conversation->participant2;
                                                    } else if ($conversation->participant2_id === $currentUser->id) {
                                                        $otherParticipant = $conversation->participant1;
                                                    } else {
                                                        // Fallback or find based on participants relationship if direct properties are not set
                                                        // This case might indicate an issue or a different structure for participants
                                                        // For now, we assume participant1 or participant2 is the current user.
                                                        // If $conversation->participants is available:
                                                        // $otherParticipant = $conversation->participants->where('id', '!=', $currentUser->id)->first();
                                                    }
                                                ?>
                                                <tr>
                                                    <td class="px-6 py-4 whitespace-no-wrap border-b border-gray-200 text-center">
                                                        <?php if($conversation->hasUnreadMessagesForUser($currentUser->id)): ?>
                                                            <svg class="w-5 h-5 text-blue-500 inline-block" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"></path><path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"></path></svg>
                                                            <span class="sr-only">Unread</span>
                                                        <?php else: ?>
                                                            <svg class="w-5 h-5 text-gray-400 inline-block" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 19v-8.93a2 2 0 01.89-1.664l7-4.666a2 2 0 012.22 0l7 4.666A2 2 0 0121 10.07V19M3 19a2 2 0 002 2h14a2 2 0 002-2M3 19l6.75-4.5M21 19l-6.75-4.5M12 12l6.75 4.5M12 12l-6.75 4.5"></path></svg>
                                                            <span class="sr-only">Read</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="px-6 py-4 whitespace-no-wrap border-b border-gray-200">
                                                        <?php if($otherParticipant): ?>
                                                        <div class="text-sm leading-5 font-medium text-gray-900">
                                                            <?php echo e($otherParticipant->name); ?>

                                                            <span class="ml-1 px-2 py-1 text-xs rounded-full
                                                                <?php if(optional($otherParticipant)->role === 'client'): ?> bg-blue-100 text-blue-800
                                                                <?php elseif(optional($otherParticipant)->role === 'admin'): ?> bg-red-100 text-red-800
                                                                <?php else: ?> bg-gray-100 text-gray-800 <?php endif; ?>">
                                                                <?php echo e(ucfirst(optional($otherParticipant)->role ?? 'User')); ?>

                                                            </span>
                                                        </div>
                                                        <div class="text-sm leading-5 text-gray-500"><?php echo e($otherParticipant->email); ?></div>
                                                        <?php else: ?>
                                                            <div class="text-sm leading-5 text-gray-500">N/A</div>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td class="px-6 py-4 whitespace-no-wrap border-b border-gray-200">
                                                        <div class="text-sm leading-5 text-gray-900">
                                                            <?php echo e($conversation->job->title ?? 'General Conversation'); ?>

                                                        </div>
                                                    </td>
                                                    <td class="px-6 py-4 border-b border-gray-200">
                                                        <div class="text-sm leading-5 text-gray-900">
                                                            <?php if($conversation->messages->isNotEmpty()): ?>
                                                                <?php echo e(\Illuminate\Support\Str::limit($conversation->messages->sortByDesc('created_at')->first()->content, 50)); ?>

                                                            <?php else: ?>
                                                                <?php echo e(__('No messages yet')); ?>

                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                    <td class="px-6 py-4 whitespace-no-wrap border-b border-gray-200 text-sm leading-5 text-gray-500">
                                                        <?php echo e(($conversation->last_message_at ?? $conversation->updated_at)->diffForHumans()); ?>

                                                    </td>
                                                    <td class="px-6 py-4 whitespace-no-wrap text-right border-b border-gray-200 text-sm leading-5 font-medium">
                                                        <a href="<?php echo e(route('freelancer.messages.show', $conversation)); ?>" class="text-cyan-600 hover:text-cyan-900"><?php echo e(__('View')); ?></a>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="mt-4">
                            <?php echo e($conversations->links()); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3437ffb4a666c895e3d1a523818d1122)): ?>
<?php $attributes = $__attributesOriginal3437ffb4a666c895e3d1a523818d1122; ?>
<?php unset($__attributesOriginal3437ffb4a666c895e3d1a523818d1122); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3437ffb4a666c895e3d1a523818d1122)): ?>
<?php $component = $__componentOriginal3437ffb4a666c895e3d1a523818d1122; ?>
<?php unset($__componentOriginal3437ffb4a666c895e3d1a523818d1122); ?>
<?php endif; ?>
<?php /**PATH D:\Coding\git\architex-lava\archiconnect-app\resources\views/freelancer/messages/index.blade.php ENDPATH**/ ?>